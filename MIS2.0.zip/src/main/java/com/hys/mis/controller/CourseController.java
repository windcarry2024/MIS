package com.hys.mis.controller;

import com.hys.mis.pojo.Result;
import com.hys.mis.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.time.LocalDate;

@CrossOrigin("*")
@RestController
public class CourseController
{
    @Autowired
    CourseService cs;

    @GetMapping("/getDailyCourses")
    public Result getDailyCourses(@DateTimeFormat(pattern = "yyyy-MM-dd") @RequestParam("date") LocalDate date)
    {
        Result result = cs.getDailyCourses(date);
        return result;
    }

    @GetMapping("/getManyDaysCourses")
    public Result getManyDaysCourses(@DateTimeFormat(pattern = "yyyy-MM-dd")
                                     @RequestParam("beginDate") LocalDate beginDate,
                                     @DateTimeFormat(pattern = "yyyy-MM-dd")
                                     @RequestParam("endDate") LocalDate endDate)
    {
        Result result = cs.getManyDaysCourses(beginDate,endDate);
        return result;
    }
}
